import { PageShell } from "../components/PageShell";

export function EffortPage() {
  return (
    <PageShell
      title="Effort"
      fullBleed
      showBottomRail={false}
      showFooter={false}
      stageClassName="pageStage--effort"
    >
      <div className="effortPageRoot">
        <div className="effortStatusTag" role="status">
          Development underway
        </div>
      </div>
    </PageShell>
  );
}
